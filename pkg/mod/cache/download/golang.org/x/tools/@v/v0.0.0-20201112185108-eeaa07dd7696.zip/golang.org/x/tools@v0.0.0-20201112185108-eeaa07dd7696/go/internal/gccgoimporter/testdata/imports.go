package imports

import "fmt"

var Hello = fmt.Sprintf("Hello, world")
